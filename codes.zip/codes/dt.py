

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 
 

data = pd.read_csv("hindu.csv")

x = data.iloc[:,1:16].values
y = data.iloc[:,16].values


from sklearn.cross_validation import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state =0 )


from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(criterion = 'entropy' , random_state =0)
classifier.fit(x_train,y_train)

y_pred = classifier.predict(x_test)


from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test,y_pred)


